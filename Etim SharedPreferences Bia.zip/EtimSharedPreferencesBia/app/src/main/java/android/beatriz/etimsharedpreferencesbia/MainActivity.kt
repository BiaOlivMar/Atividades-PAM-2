package android.beatriz.etimsharedpreferencesbia

import android.beatriz.etimsharedpreferencesbia.databinding.ActivityMainBinding
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    lateinit var binding : ActivityMainBinding

    companion object{
        const val NOME_ARQUIVO = "arquivo_prefes.xml"
    }

    private var cor = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        //supportActionBar!!.hide()
        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        binding.color1.setOnClickListener {
            cor = "#2c0001"
            salvarCor(cor)
        }

        binding.color2.setOnClickListener {
            cor = "#490206"
            salvarCor(cor)
        }

        binding.color3.setOnClickListener {
            cor = "#A9A2A1"
            salvarCor(cor)
        }

        binding.color4.setOnClickListener {
            cor = "#706b68"
            salvarCor(cor)
        }

        binding.color5.setOnClickListener {
            cor = "#27252A"
            salvarCor(cor)
        }


    }

    override fun onResume() {
        super.onResume()

        val preferencias = getSharedPreferences(NOME_ARQUIVO, MODE_PRIVATE)
        val cor = preferencias.getString("cor", "")

        if (cor!!.isNotEmpty()){
            binding.principal.setBackgroundColor(Color.parseColor(cor))
        }
    }

    private fun salvarCor(cor: String) {

        binding.principal.setBackgroundColor(Color.parseColor(cor))

        binding.troca.setOnClickListener {view ->
            val preferencias = getSharedPreferences(NOME_ARQUIVO, MODE_PRIVATE)
            val editor = preferencias.edit()
            editor.putString("cor", cor)
            editor.putString("nome", "Beatriz")
            editor.putString("sobrenome", "Marchetti")
            editor.putInt("idade", 117)
            editor.apply()
            snackBar(view)
        }
    }
    private fun  snackBar(view:View){
        val snackbar = Snackbar.make(view, "Cor de fundo alterada com sucesso!", Snackbar.LENGTH_INDEFINITE)
        snackbar.setAction("OK"){

        }
        snackbar.setActionTextColor(Color.RED)
        snackbar.setBackgroundTint(Color.BLACK)
        snackbar.setTextColor(Color.LTGRAY)
        snackbar.show()

    }
}