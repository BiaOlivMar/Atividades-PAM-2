package android.beatriz.etimpam2beatrizloginmvc.datasource;


import android.beatriz.etimpam2beatrizloginmvc.datamodel.UsuarioDataModel;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


import androidx.annotation.Nullable;


public class AppDataBase extends SQLiteOpenHelper{
    private static final String TAG = "AppDataBase";
    public static final String DB_NAME = "MVC.sqlite";
    public static int version = 1;

    public AppDataBase(Context context) {
        super(context, DB_NAME, null, version);
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(UsuarioDataModel.criarTabela());
            Log.d(TAG, "Tabela criada com sucesso!");
        } catch (Exception e) {
            Log.e(TAG, "Erro ao criar a tabela!", e);
        }
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            db.execSQL("DROP TABLE IF EXISTS " + UsuarioDataModel.TABELA);
            onCreate(db);
            Log.e(TAG, "Upgrade DB realizado: " + oldVersion + " -> " + newVersion);
        } catch (Exception e) {
            Log.e(TAG, "Erro no onUpgrade: ", e);
        }

    }

    public boolean insert(String tabela, ContentValues dados) {
        SQLiteDatabase db = null;
        long retorno = -1;

        try {
            db = getWritableDatabase();
            retorno = db.insert(tabela, null, dados);
            return retorno != -1;
        } catch (Exception e) {
           Log.e(TAG, "Erro no insert: ", e);
           return false;
        }
    }

    public Boolean checkUserPass( String email, String password ) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = getReadableDatabase();
            String sql = "SELECT 1 FROM " + UsuarioDataModel.TABELA + " WHERE email = ? AND senha = ? LIMIT 1";
            cursor = db.rawQuery(sql, new String[]{email, password});
            boolean exists = (cursor != null && cursor.getCount() > 0);
            return exists;
        } catch (Exception e) {
            Log.e(TAG, "Erro em checkUserPassword: ", e);
            return false;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public boolean checkUser( String email ) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = getWritableDatabase();
            String sql = "SELECT 1 FROM " + UsuarioDataModel.TABELA + " WHERE email = ? LIMIT 1";
            cursor = db.rawQuery(sql, new String[]{email});
            boolean exists = (cursor != null && cursor.getCount() > 0);
            return exists;
        } catch (Exception e) {
            Log.e(TAG, "Erro em checkUser: ", e);
            return false;
        } finally {
            if (cursor != null) cursor.close();
        }
    }
}
