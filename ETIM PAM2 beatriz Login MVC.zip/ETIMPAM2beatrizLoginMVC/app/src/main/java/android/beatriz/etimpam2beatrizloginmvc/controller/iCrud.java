package android.beatriz.etimpam2beatrizloginmvc.controller;

import android.beatriz.etimpam2beatrizloginmvc.model.Usuario;

import java.util.List;

public interface iCrud <T>{
    public boolean incluir(T t);
    public boolean alterar(T t);
    public boolean deletar(Usuario obj);
    public T buscar(int id);
    public List<T> listar();
}
