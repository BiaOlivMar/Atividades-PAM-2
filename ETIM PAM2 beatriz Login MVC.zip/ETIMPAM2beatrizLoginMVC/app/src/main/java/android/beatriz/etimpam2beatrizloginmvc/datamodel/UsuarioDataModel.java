package android.beatriz.etimpam2beatrizloginmvc.datamodel;


public class UsuarioDataModel {


    //Toda classe DataModel tem essa estrutura:
    // 1- Atributo nome da tabela;
    // 2- Atributos um para um com os nomes dos campos;
    // 3- Query para criar a tabela no banco de dados;
    // 4- Metodo para gerar o script para criar a tabela;


    // 1
    public static final String TABELA = "usuario";


    // 2
    public static final String ID = "id";
    public static final String NOME = "nome";
    public static final String EMAIL = "email";
    public static final String SENHA = "senha";


    // 3
    //public static String queryCriarTabela = "";


    // 4
    public static String criarTabela(){
        // Concatenação de Strings
        return "CREATE TABLE " + TABELA + " (" +
                ID     + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                NOME   + " TEXT, " +
                EMAIL  + " TEXT, " +
                SENHA  + " TEXT)";
    }
}
