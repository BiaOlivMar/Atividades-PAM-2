package android.beatriz.etimpam2beatrizloginmvc;

import android.beatriz.etimpam2beatrizloginmvc.controller.UsuarioController;
import android.beatriz.etimpam2beatrizloginmvc.model.Usuario;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private EditText email, senha, nome;
    private Button cadastrar, entrar;

    UsuarioController controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            EdgeToEdge.enable(this);
        } catch (Exception e) {
            Log.w(TAG, "EdgeToEdge falhou ai(não crítico): " + e.getMessage());
        }

        setContentView(R.layout.activity_main);

        initComponents();


        View root = findViewById(R.id.main);
        if (root != null) {
            ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        } else {
            Log.w(TAG, "root (R.id.main) é null — verifique se activity_main.xml tem um View com id 'main'");
        }

        try {
            controller = new UsuarioController(MainActivity.this);
        } catch (Exception e) {
            Log.e(TAG, "Erro ao inicializar UsuarioController/BD", e);
            Toast.makeText(this, "Erro ao iniciar o banco: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }



        entrar.setOnClickListener(view ->  {
            if(!validaCampos()) {
                //o usuário clicou no botão cadastrar
                Toast.makeText(MainActivity.this, "Não esqueça de preencher todos os campos", Toast.LENGTH_LONG).show();
                return;
            }

            String user = safeGetText(email);
            String password = safeGetText(senha);

            Log.d(TAG, "Tentativa de login -> user: " + user);

            boolean isCheckUser = false;
            try {
                isCheckUser = controller.usuarioeSenha(user, password);
            } catch (Exception e) {
                Log.e(TAG, "Erro ao realizar a verificação de usuário e senha: ", e);
                Toast.makeText(this, "Erro ao verificar as credenciaiss. Olhe LogCst", Toast.LENGTH_LONG).show();
                return;
            }




            if (isCheckUser) {
                Toast.makeText(MainActivity.this, "Login realizado com sucesso!", Toast.LENGTH_LONG).show();
                Intent home = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(home);
            } else {
                Toast.makeText(MainActivity.this, "Usuário ou senha incorretos", Toast.LENGTH_LONG).show();
            }
        });

        cadastrar.setOnClickListener(view -> {
            if (!validaCampos()) {
                Toast.makeText(MainActivity.this, "Não esqueça de preencher todos os campos", Toast.LENGTH_LONG).show();
                return;
            }

            Usuario usuario = new Usuario();
            usuario.setNome(safeGetText(nome));
            usuario.setEmail(safeGetText(email));
            usuario.setSenha(safeGetText(senha));

            Log.d(TAG, "Tentativa de cadastro -> email: " + usuario.getEmail());

            boolean sucessoCadastro = false;
            try {
                sucessoCadastro = controller.incluir(usuario);
            } catch (Exception e) {
                Log.e(TAG, "Erro no insert do DB: ", e);
                Toast.makeText(this, "Erro ao cadastrar. Veja LogCst.", Toast.LENGTH_LONG).show();
                return;
            }

            if (sucessoCadastro) {
                Toast.makeText(MainActivity.this, "Cadastro realizado com sucesso!", Toast.LENGTH_LONG).show();
                nome.setText("");
                email.setText("");
                senha.setText("");
            } else {
                Toast.makeText(MainActivity.this, "Erro ao cadastrar! Tente novamente.", Toast.LENGTH_LONG).show();
                Log.e(TAG, "insert retornou false (verifique schema/constraints)");
            }
        });
    }

    private String safeGetText(EditText et) {
        if (et == null) return "";
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    private void initComponents() {
        nome = findViewById(R.id.nome);
        email = findViewById(R.id.email);
        senha = findViewById(R.id.senha);
        cadastrar = findViewById(R.id.cadastrar);
        entrar = findViewById(R.id.entrar);
    }

    private boolean validaCampos() {
        return !(safeGetText(email).isEmpty() ||
                safeGetText(nome).isEmpty() ||
                safeGetText(senha).isEmpty());
    }
}