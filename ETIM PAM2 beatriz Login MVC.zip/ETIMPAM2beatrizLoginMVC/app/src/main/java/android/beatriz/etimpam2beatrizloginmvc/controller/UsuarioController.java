package android.beatriz.etimpam2beatrizloginmvc.controller;

import android.beatriz.etimpam2beatrizloginmvc.datamodel.UsuarioDataModel;
import android.beatriz.etimpam2beatrizloginmvc.datasource.AppDataBase;
import android.beatriz.etimpam2beatrizloginmvc.model.Usuario;
import android.content.ContentValues;
import android.content.Context;
import java.util.Collections;
import java.util.List;

public class UsuarioController implements iCrud<Usuario> {

    private AppDataBase dataSource;
    ContentValues dadosDoObjeto;

    public UsuarioController(Context context) {
        this.dataSource = new AppDataBase(context);
    }

    @Override
    public boolean incluir(Usuario usuario) {
        dadosDoObjeto = new ContentValues();
        dadosDoObjeto.put(UsuarioDataModel.NOME, usuario.getNome());
        dadosDoObjeto.put(UsuarioDataModel.EMAIL, usuario.getEmail());
        dadosDoObjeto.put(UsuarioDataModel.SENHA, usuario.getSenha());

        return dataSource.insert(UsuarioDataModel.TABELA, dadosDoObjeto);
    }

    @Override
    public boolean alterar(Usuario obj) {
        return false;
    }

    @Override
    public boolean deletar(Usuario obj) {
        return false;
    }

    @Override
    public Usuario buscar(int id) {
        return null;
    }

    @Override
    public List<Usuario> listar() {
        return Collections.emptyList();
    }

    public boolean usuarioeSenha(String username, String password) {
        return dataSource.checkUserPass(username, password);
    }

    public boolean usuario(String user) {
        return dataSource.checkUser(user);
    }
}