package android.beatriz.etimpam2beatrizloginmvc.controller;

import android.beatriz.etimpam2beatrizloginmvc.datamodel.UsuarioDataModel;
import android.beatriz.etimpam2beatrizloginmvc.datasource.AppDataBase;
import android.beatriz.etimpam2beatrizloginmvc.model.Usuario;
import android.content.ContentValues;
import android.content.Context;

import java.util.Collections;
import java.util.List;

public class UsuarioController extends AppDataBase implements iCrud<Usuario> {
    ContentValues dadosDoObjeto;
    public UsuarioController(Context context) {
        super(context);
    }

    @Override
    public boolean incluir(Usuario obj) {
        dadosDoObjeto = new ContentValues();
        dadosDoObjeto.put(UsuarioDataModel.NOME, obj.getUserName() );
        dadosDoObjeto.put(UsuarioDataModel.EMAIL, obj.getUserEmail() );
        dadosDoObjeto.put(UsuarioDataModel.SENHA, obj.getPassword() );

        return insert(UsuarioDataModel.TABELA, dadosDoObjeto);
    }

    @Override
    public boolean alterar(Usuario obj) {
        return false;
    }

    @Override
    public boolean deletar(Usuario obj) {
        return false;
    }

    @Override
    public List<Usuario> listar() {
        return Collections.emptyList();
    }
}
